# ChatGPT Clone

A local chat app that talks to Google's Gemini API — for free, no credit
card required — and answers questions the way ChatGPT does, including
remembering earlier turns in the same conversation.

## What changed from the original tutorial version

- Switched from the deprecated `text-davinci-003` completion API to the
  current chat completions API, so it actually works and gives real, full
  answers to any question — not lookups against a fixed Q&A table.
- Uses **Google's Gemini API** (free tier, no credit card) instead of
  OpenAI's paid API, through Gemini's OpenAI-compatible endpoint — so the
  code still uses the familiar `openai` Python package under the hood.
- The whole conversation history is sent with every request, so follow-up
  questions and corrections work like real ChatGPT.
- Removed the hardcoded API key and MongoDB password from the source. Your
  key now lives in a local `.env` file that's git-ignored.
- Replaced the MongoDB dependency with a simple local JSON file, so there's
  nothing extra to sign up for to get this running.
- Rebuilt the front end so a full conversation thread renders (not just one
  static question/answer pair), with a working sidebar, new chat button, and
  delete button.
- Tailwind is now loaded via CDN, so there's no npm build step required.

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Get a free API key (no credit card needed) at https://ai.google.dev
   -> sign in with a Google account -> "Get API key" -> create a key.
3. Copy `.env.example` to `.env` and paste your key in:
   ```bash
   cp .env.example .env
   ```
4. Run it:
   ```bash
   python app.py
   ```
5. Open http://127.0.0.1:5001 in your browser.

## Notes

- Conversations are stored in `data/conversations.json` on your machine.
- The Gemini free tier has a daily request limit (generous for personal
  use/testing, but not unlimited) and Google may use free-tier prompts to
  improve its models -- fine for a school project, avoid it for private or
  sensitive data.
- Want to switch to OpenAI or another provider later? Just change the
  `base_url` and API key in `app.py` -- the rest of the code stays the same.
