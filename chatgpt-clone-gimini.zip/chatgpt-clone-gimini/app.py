"""
ChatGPT Clone - Flask backend

Runs a local chat app that talks to Google's free Gemini API (via its
OpenAI-compatible endpoint) and remembers the full conversation history,
the way ChatGPT does.

Setup:
    1. pip install -r requirements.txt
    2. Get a free key (no credit card) at https://ai.google.dev
    3. Copy .env.example to .env and add your own GEMINI_API_KEY
    4. python app.py
    5. Open http://127.0.0.1:5001
"""

import json
import os
import uuid
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from openai import OpenAI

load_dotenv()  # reads variables from a local .env file, if present

app = Flask(__name__)

# --- LLM client -----------------------------------------------------
# Uses Google's Gemini API (free, no credit card) through its
# OpenAI-compatible endpoint, so the rest of the code below can stay
# exactly the same as if it were calling OpenAI directly.
# The API key is NEVER hardcoded here. Set it as an environment variable
# (see .env.example) so it never ends up committed to source control.
api_key = os.environ.get("GEMINI_API_KEY")
client = (
    OpenAI(
        api_key=api_key,
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
    )
    if api_key
    else None
)

MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM_PROMPT = (
    "You are a helpful, knowledgeable assistant. Answer the user's "
    "questions as clearly and completely as you can, the way ChatGPT "
    "does. If you are genuinely unsure about something, say so rather "
    "than making it up."
)

# --- Storage -------------------------------------------------------------
# Simple local JSON file instead of MongoDB, so there's nothing extra to
# sign up for or configure to get this running. Swap in a real database
# later if you want persistence across machines / multiple users.
DATA_FILE = Path(__file__).parent / "data" / "conversations.json"
DATA_FILE.parent.mkdir(exist_ok=True)


def load_conversations():
    if not DATA_FILE.exists():
        return {}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_conversations(conversations):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(conversations, f, indent=2)


# --- Routes --------------------------------------------------------------

@app.route("/")
def home():
    conversations = load_conversations()
    # newest first, only need id + title for the sidebar
    sidebar_chats = [
        {"id": cid, "title": c["title"]}
        for cid, c in sorted(
            conversations.items(), key=lambda kv: kv[1]["created_at"], reverse=True
        )
    ]
    return render_template("index.html", chats=sidebar_chats)


@app.route("/api/conversations/<conversation_id>", methods=["GET"])
def get_conversation(conversation_id):
    conversations = load_conversations()
    convo = conversations.get(conversation_id)
    if not convo:
        return jsonify({"error": "Conversation not found"}), 404
    return jsonify(convo)


@app.route("/api/conversations/<conversation_id>", methods=["DELETE"])
def delete_conversation(conversation_id):
    conversations = load_conversations()
    conversations.pop(conversation_id, None)
    save_conversations(conversations)
    return jsonify({"ok": True})


@app.route("/api/chat", methods=["POST"])
def chat():
    if client is None:
        return jsonify({
            "error": "No GEMINI_API_KEY is set. Add one to your .env file "
                     "(see .env.example) and restart the server."
        }), 500

    body = request.json or {}
    message = (body.get("message") or "").strip()
    conversation_id = body.get("conversation_id")

    if not message:
        return jsonify({"error": "Message cannot be empty"}), 400

    conversations = load_conversations()

    # Start a new conversation if needed
    if not conversation_id or conversation_id not in conversations:
        conversation_id = str(uuid.uuid4())
        conversations[conversation_id] = {
            "id": conversation_id,
            "title": message[:60],
            "created_at": __import__("time").time(),
            "messages": [],
        }

    convo = conversations[conversation_id]
    convo["messages"].append({"role": "user", "content": message})

    # Build the full message list so the model has the entire conversation
    # in context, not just the latest question - this is what makes it
    # "remember" earlier turns like real ChatGPT.
    api_messages = [{"role": "system", "content": SYSTEM_PROMPT}] + [
        {"role": m["role"], "content": m["content"]} for m in convo["messages"]
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=api_messages,
            temperature=0.7,
        )
        answer = response.choices[0].message.content
    except Exception as exc:  # noqa: BLE001 - surface any API error to the UI
        return jsonify({"error": f"Gemini request failed: {exc}"}), 502

    convo["messages"].append({"role": "assistant", "content": answer})
    save_conversations(conversations)

    return jsonify({
        "conversation_id": conversation_id,
        "title": convo["title"],
        "answer": answer,
    })


if __name__ == "__main__":
    app.run(debug=True, port=5001)
