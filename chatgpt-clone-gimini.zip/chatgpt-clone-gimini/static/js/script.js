const questionInput = document.getElementById("questionInput");
const sendButton = document.getElementById("sendButton");
const welcomeScreen = document.getElementById("welcomeScreen");
const chatScreen = document.getElementById("chatScreen");
const messagesEl = document.getElementById("messages");
const chatList = document.getElementById("chatList");
const newChatBtn = document.getElementById("newChatBtn");
const errorBanner = document.getElementById("errorBanner");

let activeConversationId = null;
let isSending = false;

function showError(text) {
    errorBanner.textContent = text;
    errorBanner.classList.remove("hidden");
}

function clearError() {
    errorBanner.classList.add("hidden");
    errorBanner.textContent = "";
}

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

// Very small formatter: turns ```code``` fences into <pre> blocks and
// keeps everything else as plain escaped text with line breaks preserved.
function formatMessage(text) {
    const parts = text.split(/```/g);
    return parts
        .map((part, i) => {
            if (i % 2 === 1) {
                return `<pre class="bg-black/40 rounded-md p-3 my-2 overflow-x-auto text-sm"><code>${escapeHtml(part)}</code></pre>`;
            }
            return escapeHtml(part).replace(/\n/g, "<br>");
        })
        .join("");
}

function appendMessage(role, content) {
    const isUser = role === "user";
    const row = document.createElement("div");
    row.className = `w-full py-6 px-4 md:px-10 ${isUser ? "bg-transparent" : "bg-black/20"}`;
    row.innerHTML = `
        <div class="max-w-2xl mx-auto flex space-x-4">
            <div class="shrink-0 w-8 h-8 rounded-sm flex items-center justify-center text-sm font-bold ${isUser ? "bg-emerald-600" : "bg-violet-600"
        }">
                ${isUser ? "U" : "AI"}
            </div>
            <div class="leading-relaxed whitespace-pre-wrap">${formatMessage(content)}</div>
        </div>`;
    messagesEl.appendChild(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return row;
}

function appendTypingIndicator() {
    const row = document.createElement("div");
    row.id = "typingIndicator";
    row.className = "w-full py-6 px-4 md:px-10 bg-black/20";
    row.innerHTML = `
        <div class="max-w-2xl mx-auto flex space-x-4">
            <div class="shrink-0 w-8 h-8 rounded-sm flex items-center justify-center text-sm font-bold bg-violet-600">AI</div>
            <div class="opacity-60 animate-pulse">Thinking…</div>
        </div>`;
    messagesEl.appendChild(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

function removeTypingIndicator() {
    document.getElementById("typingIndicator")?.remove();
}

function showChatScreen() {
    welcomeScreen.classList.add("hidden");
    chatScreen.classList.remove("hidden");
}

function showWelcomeScreen() {
    chatScreen.classList.add("hidden");
    welcomeScreen.classList.remove("hidden");
    messagesEl.innerHTML = "";
    activeConversationId = null;
    document.querySelectorAll(".chat-item").forEach((el) => el.classList.remove("bg-white/10"));
}

function addSidebarEntry(id, title) {
    const existing = chatList.querySelector(`[data-id="${id}"]`);
    if (existing) return;
    const item = document.createElement("div");
    item.className = "chat-item group w-full px-3 py-2 rounded-md hover:bg-white/10 cursor-pointer flex justify-between items-center text-sm truncate";
    item.dataset.id = id;
    item.innerHTML = `<span class="truncate">${escapeHtml(title)}</span>
        <button class="delete-btn opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-400 ml-2" data-id="${id}">✕</button>`;
    chatList.prepend(item);
}

async function loadConversation(id) {
    clearError();
    const res = await fetch(`/api/conversations/${id}`);
    if (!res.ok) {
        showError("Couldn't load that conversation.");
        return;
    }
    const convo = await res.json();
    activeConversationId = id;
    messagesEl.innerHTML = "";
    convo.messages.forEach((m) => appendMessage(m.role, m.content));
    showChatScreen();
    document.querySelectorAll(".chat-item").forEach((el) => {
        el.classList.toggle("bg-white/10", el.dataset.id === id);
    });
}

async function sendMessage(text) {
    const message = text.trim();
    if (!message || isSending) return;

    clearError();
    isSending = true;
    sendButton.disabled = true;

    showChatScreen();
    appendMessage("user", message);
    appendTypingIndicator();
    questionInput.value = "";

    try {
        const res = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message, conversation_id: activeConversationId }),
        });
        const data = await res.json();
        removeTypingIndicator();

        if (!res.ok) {
            showError(data.error || "Something went wrong talking to the model.");
            return;
        }

        if (!activeConversationId) {
            activeConversationId = data.conversation_id;
            addSidebarEntry(data.conversation_id, data.title);
        }
        appendMessage("assistant", data.answer);
    } catch (err) {
        removeTypingIndicator();
        showError("Network error — is the Flask server running?");
    } finally {
        isSending = false;
        sendButton.disabled = false;
    }
}

sendButton.addEventListener("click", () => sendMessage(questionInput.value));
questionInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage(questionInput.value);
});

newChatBtn.addEventListener("click", showWelcomeScreen);

const infoBtn = document.getElementById("infoBtn");
const infoPanel = document.getElementById("infoPanel");

infoBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    infoPanel.classList.toggle("hidden");
});

// Close the panel when clicking anywhere else on the page
document.addEventListener("click", (e) => {
    if (!infoPanel.classList.contains("hidden") && !infoPanel.contains(e.target) && e.target !== infoBtn) {
        infoPanel.classList.add("hidden");
    }
});

chatList.addEventListener("click", (e) => {
    const deleteBtn = e.target.closest(".delete-btn");
    if (deleteBtn) {
        e.stopPropagation();
        const id = deleteBtn.dataset.id;
        fetch(`/api/conversations/${id}`, { method: "DELETE" }).then(() => {
            deleteBtn.closest(".chat-item").remove();
            if (activeConversationId === id) showWelcomeScreen();
        });
        return;
    }
    const item = e.target.closest(".chat-item");
    if (item) loadConversation(item.dataset.id);
});
